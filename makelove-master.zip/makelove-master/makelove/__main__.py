from .makelove import main

main()
